"use client";

import { LoaderIcon } from "lucide-react";
import * as React from "react";

export function LoadingIcon() {
  return <LoaderIcon size={14} className="animate-spin" />;
}
