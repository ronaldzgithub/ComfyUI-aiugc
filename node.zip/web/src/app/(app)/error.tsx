"use client";

import { ErrorFullPage } from "@/components/docs/ErrorPage";

export default ErrorFullPage;
