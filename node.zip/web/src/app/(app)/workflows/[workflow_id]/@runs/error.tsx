"use client";

import ErrorPage from "@/components/docs/ErrorPage";

export default ErrorPage;
