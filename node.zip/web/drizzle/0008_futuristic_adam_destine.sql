ALTER SCHEMA "comfy_deploy" RENAME TO "comfyui_deploy";
