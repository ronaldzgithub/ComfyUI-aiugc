ALTER TABLE "comfyui_deploy"."machines" ADD COLUMN "org_id" text;--> statement-breakpoint
ALTER TABLE "comfyui_deploy"."workflows" ADD COLUMN "org_id" text;